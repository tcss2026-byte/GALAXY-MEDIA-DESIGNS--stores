# v6 — Production-ready additions

## New
- **Real WebRTC 1:1 voice & video calls** (`js/webrtc.js`, `pages/call.html`, `js/call.js`, `css/call.css`)
  - Firebase RTDB signaling under `rtc/{callId}` + `incoming/{uid}/{callId}`
  - Mute, camera toggle, speaker toggle, end-call; 30s no-answer → missed
  - Global incoming-call listener in `js/presence.js` (rings on any page)
- **`@ai` inline bot inside any chat** (`js/ai-mention.js`)
  - Type `@ai <question>` → Gemini reply appears in the chat
  - Uses `/api/chat` by default; override with `window.LT_AI_URL`
- **HOSTING.md** with Firebase RTDB rules, Storage rules, TURN guidance

## Updated
- `js/calls.js` → launches real `call.html`, adds voice + video buttons per row
- `js/presence.js` → routes incoming calls to call screen

## What WhatsApp parity v6 ships
| Area | Status |
|---|---|
| Auth (register/login) | ✅ Firebase email/password |
| Chats list, unread, last msg, ticks, typing, online, last seen | ✅ |
| Chat: reply, react, forward, delete-for-me / for-everyone, media, voice notes | ✅ |
| `@ai` in chat | ✅ NEW |
| Status: text/image/video, viewers, reply, react, reshare, delete-own | ✅ |
| Groups: create, members, admin promote/demote, add/remove, only-admin post, exit, delete | ✅ |
| 1:1 voice + video calls (WebRTC) | ✅ NEW |
| Call history (missed/in/out) | ✅ |
| Settings, profile, theme, privacy, clear chats | ✅ |

## Not in v6 (documented in HOSTING.md)
- Group calls
- End-to-end encryption
- Push notifications when app is closed (FCM service worker)
