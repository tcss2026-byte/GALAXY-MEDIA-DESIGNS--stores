const firebaseConfig = {
  apiKey: "AIzaSyAG_p194TBqulNpGv3oRpwI-HRRbCx8OJc",
  authDomain: "wt2m-5f91f.firebaseapp.com",
  databaseURL: "https://wt2m-5f91f-default-rtdb.firebaseio.com",
  projectId: "wt2m-5f91f",
  storageBucket: "wt2m-5f91f.firebasestorage.app",
  messagingSenderId: "810807180193",
  appId: "1:810807180193:web:c33b7da75e8f3817fe29e0"
};

firebase.initializeApp(firebaseConfig);

// console.log(firebase);
// console.log("database =", firebase.database);
// console.log("auth =", firebase.auth);
// console.log("storage =", firebase.storage);

const auth = firebase.auth();
const db = firebase.database();
const storage = firebase.storage ? firebase.storage() : null;

function currentUser() {
    return auth.currentUser;
}