auth.onAuthStateChanged(user => {
  if (!user) return;

  db.ref('users/' + user.uid + '/settings')
    .once('value')
    .then(snapshot => {

      const settings = snapshot.val() || {};

      const lastSeen = document.getElementById('lastSeen');
      const receipts = document.getElementById('receipts');

      if (lastSeen) {
        lastSeen.value = settings.lastSeen || 'everyone';
      }

      if (receipts) {
        receipts.checked = settings.readReceipts !== false;
      }
    });
});

function savePrivacy() {

  const user = auth.currentUser;
  if (!user) return;

  const lastSeen = document.getElementById('lastSeen');
  const receipts = document.getElementById('receipts');

  db.ref('users/' + user.uid + '/settings').update({
    lastSeen: lastSeen.value,
    readReceipts: receipts.checked
  });
}

window.savePrivacy = savePrivacy;