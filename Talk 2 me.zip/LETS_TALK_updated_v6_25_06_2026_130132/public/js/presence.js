// Online / Last-seen presence + global incoming-call listener
auth.onAuthStateChanged(user => {
  if (!user) return;
  const userStatusRef = db.ref('/status/' + user.uid);
  const isOffline = { state: 'offline', last_changed: firebase.database.ServerValue.TIMESTAMP };
  const isOnline  = { state: 'online',  last_changed: firebase.database.ServerValue.TIMESTAMP };

  db.ref('.info/connected').on('value', snap => {
    if (snap.val() === false) return;
    userStatusRef.onDisconnect().set(isOffline).then(() => userStatusRef.set(isOnline));
  });

  // Global incoming-call listener: jumps to call screen on any page
  if (!location.pathname.endsWith('call.html')) {
    const inbox = db.ref('incoming/' + user.uid);
    inbox.on('child_added', snap => {
      const c = snap.val(); if (!c || !c.from) return;
      // Avoid stale rings (>60s)
      if (Date.now() - (c.time || 0) > 60000) { snap.ref.remove(); return; }
      const callId = snap.key;
      snap.ref.remove();
      const base = location.pathname.includes('/pages/') ? '' : 'pages/';
      location.href = `${base}call.html?mode=in&uid=${c.from}&kind=${c.kind||'voice'}&callId=${callId}`;
    });
  }
});
