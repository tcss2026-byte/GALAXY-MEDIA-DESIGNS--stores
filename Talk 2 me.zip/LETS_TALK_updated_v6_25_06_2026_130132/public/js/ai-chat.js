// AI chat page logic
// - Persists conversation locally per user so refresh keeps context
// - Sends full history to the backend for coherent multi-turn replies
// - Shows a typing indicator while waiting

const form = document.getElementById("composer");
const input = document.getElementById("prompt");
const messages = document.getElementById("messages");

const HISTORY_LIMIT = 30;
let me = null;
let history = []; // [{role:'user'|'assistant', text}]

function storageKey() {
  return "ai_history_" + (me ? me.uid : "anon");
}

function loadHistory() {
  try {
    const raw = localStorage.getItem(storageKey());
    history = raw ? JSON.parse(raw) : [];
  } catch { history = []; }
}

function saveHistory() {
  try {
    localStorage.setItem(
      storageKey(),
      JSON.stringify(history.slice(-HISTORY_LIMIT))
    );
  } catch {}
}

function renderMessage(text, role) {
  const msg = document.createElement("div");
  msg.className = "msg " + (role === "user" ? "me" : "other");
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  msg.appendChild(bubble);
  messages.appendChild(msg);
  messages.scrollTop = messages.scrollHeight;
  return bubble;
}

function renderAll() {
  // Keep the greeting (first .msg.other), append history below it
  const greeting = messages.querySelector(".msg");
  messages.innerHTML = "";
  if (greeting) messages.appendChild(greeting);
  for (const turn of history) renderMessage(turn.text, turn.role);
}

auth.onAuthStateChanged((user) => {
  if (!user) { location.href = "login.html"; return; }
  me = user;
  loadHistory();
  renderAll();
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const prompt = input.value.trim();
  if (!prompt) return;

  renderMessage(prompt, "user");
  history.push({ role: "user", text: prompt });
  saveHistory();
  input.value = "";

  const typingBubble = renderMessage("typing…", "assistant");
  typingBubble.classList.add("typing");

  const reply = await AI.chat(history.slice(-HISTORY_LIMIT));
  typingBubble.classList.remove("typing");
  typingBubble.textContent = reply;

  history.push({ role: "assistant", text: reply });
  saveHistory();
});

// Long-press the AI avatar / title bar to clear history
document.addEventListener("DOMContentLoaded", () => {
  const bar = document.querySelector(".chat-bar");
  if (!bar) return;
  let timer = null;
  const start = () => { timer = setTimeout(clearHistory, 700); };
  const cancel = () => { clearTimeout(timer); };
  bar.addEventListener("mousedown", start);
  bar.addEventListener("touchstart", start, { passive: true });
  ["mouseup","mouseleave","touchend","touchcancel"].forEach(ev =>
    bar.addEventListener(ev, cancel));
});

function clearHistory() {
  if (!confirm("Clear AI conversation?")) return;
  history = [];
  saveHistory();
  renderAll();
}
