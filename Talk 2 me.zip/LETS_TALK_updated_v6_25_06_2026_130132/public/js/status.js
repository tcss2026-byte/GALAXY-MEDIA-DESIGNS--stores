// ================================
// STATUS.JS - Posting & listing
// ================================

const STATUS_TTL = 24 * 60 * 60 * 1000; // 24h

const myStatusItem = document.getElementById("myStatusItem");
const myAvatar     = document.getElementById("myAvatar");
const myStatusText = document.getElementById("myStatusText");
const recentList   = document.getElementById("recentList");
const viewedList   = document.getElementById("viewedList");
const recentTitle  = document.getElementById("recentTitle");
const viewedTitle  = document.getElementById("viewedTitle");

const fabAI         = document.getElementById("fabAI");
const composeFab    = document.getElementById("composeFab");
const cameraFab     = document.getElementById("cameraFab");
const statusFile    = document.getElementById("statusFile");
const composeOverlay= document.getElementById("composeOverlay");
const closeCompose  = document.getElementById("closeCompose");
const composeText   = document.getElementById("composeText");
const sendCompose   = document.getElementById("sendCompose");
const composeColor  = document.getElementById("composeColor");
const privacyBtn    = document.getElementById("privacyBtn");
const menuBtn       = document.getElementById("menuBtn");

if (fabAI)      fabAI.onclick      = () => location.href = "ai-chat.html";
if (privacyBtn) privacyBtn.onclick = () => alert("Status privacy settings\nOnly your contacts can see your status updates.");
if (menuBtn)    menuBtn.onclick    = () => {
  if (confirm("Status updates disappear after 24 hours.\n\nView muted updates?")) {
    alert("No muted updates.");
  }
};

// ---------- Compose text status ----------
const BG_COLORS = ["#075e54","#128c7e","#1f3a93","#c0392b","#7b1fa2","#e67e22","#2c3e50"];
let bgIdx = 0;

if (composeFab) composeFab.onclick = () => {
  composeOverlay.hidden = false;
  composeText.value = "";
  composeText.focus();
};
if (closeCompose) closeCompose.onclick = () => composeOverlay.hidden = true;
if (composeColor) composeColor.onclick = () => {
  bgIdx = (bgIdx + 1) % BG_COLORS.length;
  composeOverlay.style.background = BG_COLORS[bgIdx];
};

if (sendCompose) sendCompose.onclick = async () => {
  const txt = composeText.value.trim();
  if (!txt) return;
  const user = auth.currentUser;
  if (!user) return;
  await db.ref("status/" + user.uid).push({
    type: "text",
    text: txt,
    bg: BG_COLORS[bgIdx],
    time: Date.now(),
    views: {}
  });
  composeOverlay.hidden = true;
  composeOverlay.style.background = "";
  bgIdx = 0;
};

// ---------- Camera / media ----------
if (cameraFab) cameraFab.onclick = () => statusFile.click();

if (statusFile) statusFile.onchange = async e => {
  const file = e.target.files[0];
  if (!file) return;
  const user = auth.currentUser;
  if (!user) return;
  const ref = storage.ref("status/" + user.uid + "/" + Date.now() + "_" + file.name);
  const snap = await ref.put(file);
  const url  = await snap.ref.getDownloadURL();
  await db.ref("status/" + user.uid).push({
    type: file.type.startsWith("video") ? "video" : "image",
    url,
    time: Date.now(),
    views: {}
  });
  statusFile.value = "";
};

// ---------- User cache ----------
const userCache = {};
function getUser(uid){
  if (userCache[uid]) return Promise.resolve(userCache[uid]);
  return db.ref("users/"+uid).once("value").then(s=>{
    userCache[uid] = s.val()||{};
    return userCache[uid];
  });
}
function avatarHTML(u){
  if (u.photoURL) return `<img src="${u.photoURL}" alt="">`;
  return (u.name||"?")[0].toUpperCase();
}
function fmtTime(t){
  if (!t) return "";
  const m = Math.floor((Date.now()-t)/60000);
  if (m<1) return "just now";
  if (m<60) return m+" min ago";
  const h = Math.floor(m/60);
  if (h<24) return h+" h ago";
  return new Date(t).toLocaleDateString();
}

// ---------- Load statuses ----------
auth.onAuthStateChanged(async user => {
  if (!user) return;
  const me = await getUser(user.uid);
  myAvatar.innerHTML = avatarHTML(me);
  myStatusItem.onclick = () => {
    location.href = "status-view.html?uid=" + user.uid;
  };

  loadAll(user.uid);
});

function loadAll(myUid){
  db.ref("status").on("value", async snap => {
    const all = snap.val() || {};
    recentList.innerHTML = "";
    viewedList.innerHTML = "";
    let recent = 0, viewed = 0;
    const now = Date.now();

    // my status preview
    const mine = Object.values(all[myUid]||{}).filter(s=>(now-s.time)<STATUS_TTL);
    if (mine.length){
      myStatusItem.querySelector(".avatar").classList.add("status-ring","mine");
      myStatusItem.querySelector(".avatar").classList.remove("status-add-icon");
      const last = mine.sort((a,b)=>b.time-a.time)[0];
      myStatusText.textContent = (mine.length+" update"+(mine.length>1?"s":""))+" • "+fmtTime(last.time);
    } else {
      myStatusItem.querySelector(".avatar").classList.add("status-add-icon");
      myStatusText.textContent = "Tap to add status update";
    }

    // Show statuses from every other user that has at least one active status.
    // (WhatsApp-style: viewed vs unviewed sections.)
    const contacts = Object.keys(all).filter(uid => uid !== myUid);

    for (const uid of contacts){

      const list = Object.entries(all[uid]||{}).filter(([,s])=>(now-s.time)<STATUS_TTL);
      if (!list.length) continue;
      const u = await getUser(uid);
      const last = list.sort((a,b)=>b[1].time-a[1].time)[0][1];
      const seenByMe = list.every(([,s])=>s.views && s.views[myUid]);

      const item = document.createElement("div");
      item.className = "list-item";
      item.innerHTML = `
        <div class="avatar status-ring ${seenByMe?'seen':''}">${avatarHTML(u)}</div>
        <div class="meta">
          <div class="name"><span>${u.name||"User"}</span></div>
          <div class="snippet">${list.length} update${list.length>1?'s':''} • ${fmtTime(last.time)}</div>
        </div>`;
      item.onclick = () => location.href = "status-view.html?uid="+uid;

      if (seenByMe){ viewedList.appendChild(item); viewed++; }
      else { recentList.appendChild(item); recent++; }
    }

    recentTitle.hidden = recent===0;
    viewedTitle.hidden = viewed===0;
  });
}
