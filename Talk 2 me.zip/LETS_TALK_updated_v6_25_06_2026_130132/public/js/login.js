const form = document.getElementById('loginForm');
const err = document.getElementById('err');

auth.onAuthStateChanged(u => { if (u) location.href = 'home.html'; });

form.addEventListener('submit', async e => {
  e.preventDefault();
  err.classList.remove('show');
  const email = document.getElementById('email').value.trim();
  const pass  = document.getElementById('password').value;
  try {
    await auth.signInWithEmailAndPassword(email, pass);
    location.href = 'home.html';
  } catch (ex) {
    err.textContent = ex.message;
    err.classList.add('show');
  }
});
