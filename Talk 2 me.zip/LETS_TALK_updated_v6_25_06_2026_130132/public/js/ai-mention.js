// ai-mention.js — type "@ai <question>" in any 1:1 or group chat
// to get an inline reply from LET'S TALK AI (powered by Gemini).
// Loaded AFTER chat.js inside chat.html.

(function(){
  const AI_UID = "ai-bot";
  const AI_NAME = "LET'S TALK AI";
  // Override at runtime: window.LT_AI_URL = "https://your-server.example.com/api/chat";
  const API = (window.LT_AI_URL) || "/api/chat";

  // Seed the bot user once so chat UI shows a nice name/avatar.
  db.ref("users/" + AI_UID).once("value").then(s => {
    if (!s.exists()) {
      db.ref("users/" + AI_UID).set({
        name: AI_NAME, email: "ai@letstalk.app",
        photoURL: "", isBot: true, online: true
      });
    }
  });

  function chatIdOf(a, b){ return [a,b].sort().join("_"); }
  function currentChatPath(){
    const p = new URLSearchParams(location.search);
    if (p.get("gid")) return "group_" + p.get("gid");
    const peer = p.get("uid");
    const u = firebase.auth().currentUser;
    if (!peer || !u) return null;
    return chatIdOf(u.uid, peer);
  }

  function postAIReply(chatPath, text){
    db.ref("messages/" + chatPath).push({
      from: AI_UID, time: Date.now(), type: "text", text,
      // a tiny marker the UI can read if it wants to render an AI badge
      ai: true
    });
  }

  async function askAI(question, history){
    try {
      const r = await fetch(API + "/history", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ history: history.concat([{role:"user", text: question}]) })
      });
      if (!r.ok) throw new Error("AI " + r.status);
      const j = await r.json();
      return j.reply || "(no reply)";
    } catch (e) {
      // Fallback: try single-shot
      try {
        const r2 = await fetch(API, {
          method: "POST", headers: {"Content-Type":"application/json"},
          body: JSON.stringify({ message: question })
        });
        const j2 = await r2.json();
        return j2.reply || "AI is unavailable right now.";
      } catch(_) {
        return "⚠️ AI is unavailable. Make sure the server is running and reachable.";
      }
    }
  }

  // Watch the live chat for new messages from me containing @ai
  let lastSeenKey = null;
  let started = false;

  firebase.auth().onAuthStateChanged(user => {
    if (!user || started) return;
    started = true;
    const chatPath = currentChatPath();
    if (!chatPath) return;

    const ref = db.ref("messages/" + chatPath).limitToLast(20);
    ref.on("child_added", async snap => {
      // skip initial backlog
      if (!lastSeenKey) { lastSeenKey = snap.key; return; }
      lastSeenKey = snap.key;

      const m = snap.val();
      if (!m || m.from !== user.uid || m.type !== "text") return;
      const text = String(m.text||"").trim();
      const match = text.match(/^@ai\s+([\s\S]+)/i);
      if (!match) return;
      const question = match[1].trim();
      if (!question) return;

      // pull recent context (last 10 msgs) to give the AI continuity
      const recent = await db.ref("messages/"+chatPath).limitToLast(10).once("value");
      const history = [];
      recent.forEach(s => {
        const x = s.val();
        if (!x || !x.text) return;
        history.push({ role: x.from === AI_UID ? "model" : "user", text: x.text });
      });

      const reply = await askAI(question, history);
      postAIReply(chatPath, reply);
    });
  });
})();
