// ==========================================================
// webrtc.js — 1:1 voice/video call helper (Firebase RTDB signaling)
// Exposes window.LTRTC = { startCall, acceptCall, endCall }
// ==========================================================
(function () {
  const STUN = {
    iceServers: [
      { urls: "stun:stun.l.google.com:19302" },
      { urls: "stun:stun1.l.google.com:19302" },
      { urls: "stun:global.stun.twilio.com:3478" }
    ]
  };

  // Optional TURN: window.LT_TURN = [{urls:..., username:..., credential:...}]
  if (window.LT_TURN && Array.isArray(window.LT_TURN)) {
    STUN.iceServers.push(...window.LT_TURN);
  }

  let pc = null;
  let localStream = null;
  let remoteStream = null;
  let callRef = null;
  let unsubs = [];
  let role = null; // "caller" | "callee"
  let kind = "voice";

  async function getMedia(k) {
    return navigator.mediaDevices.getUserMedia({
      audio: true,
      video: k === "video" ? { width: 640, height: 480, facingMode: "user" } : false
    });
  }

  function attachRemote(videoEl, audioEl) {
    remoteStream = new MediaStream();
    pc.ontrack = (ev) => {
      ev.streams[0].getTracks().forEach(t => remoteStream.addTrack(t));
      if (videoEl) videoEl.srcObject = remoteStream;
      if (audioEl) audioEl.srcObject = remoteStream;
    };
  }

  function pushCandidate(path, cand) {
    callRef.child(path).push(cand.toJSON());
  }

  function listenCandidates(path) {
    const ref = callRef.child(path);
    const handler = ref.on("child_added", snap => {
      const c = snap.val();
      if (c && pc) pc.addIceCandidate(new RTCIceCandidate(c)).catch(()=>{});
    });
    unsubs.push(() => ref.off("child_added", handler));
  }

  async function startCall({ callId, peerUid, myUid, kind: k, localVideo, remoteVideo, remoteAudio, onState }) {
    role = "caller"; kind = k || "voice";
    callRef = db.ref("rtc/" + callId);
    pc = new RTCPeerConnection(STUN);
    attachRemote(remoteVideo, remoteAudio);

    localStream = await getMedia(kind);
    if (localVideo && kind === "video") localVideo.srcObject = localStream;
    localStream.getTracks().forEach(t => pc.addTrack(t, localStream));

    pc.onicecandidate = e => { if (e.candidate) pushCandidate("callerCandidates", e.candidate); };
    pc.onconnectionstatechange = () => onState && onState(pc.connectionState);

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    await callRef.set({
      from: myUid, to: peerUid, kind, time: Date.now(),
      offer: { type: offer.type, sdp: offer.sdp }, status: "ringing"
    });

    // Notify callee
    await db.ref("incoming/" + peerUid + "/" + callId).set({
      from: myUid, kind, time: Date.now()
    });

    // Wait for answer
    const ansRef = callRef.child("answer");
    const ansH = ansRef.on("value", async snap => {
      const a = snap.val();
      if (a && pc && !pc.currentRemoteDescription) {
        await pc.setRemoteDescription(new RTCSessionDescription(a));
        onState && onState("connected-answer");
      }
    });
    unsubs.push(() => ansRef.off("value", ansH));
    listenCandidates("calleeCandidates");

    // End detection
    const stRef = callRef.child("status");
    const stH = stRef.on("value", s => {
      if (s.val() === "ended") endCall(true);
    });
    unsubs.push(() => stRef.off("value", stH));
  }

  async function acceptCall({ callId, myUid, localVideo, remoteVideo, remoteAudio, onState }) {
    role = "callee";
    callRef = db.ref("rtc/" + callId);
    const data = (await callRef.once("value")).val();
    if (!data || !data.offer) throw new Error("Call not found");
    kind = data.kind || "voice";

    pc = new RTCPeerConnection(STUN);
    attachRemote(remoteVideo, remoteAudio);

    localStream = await getMedia(kind);
    if (localVideo && kind === "video") localVideo.srcObject = localStream;
    localStream.getTracks().forEach(t => pc.addTrack(t, localStream));

    pc.onicecandidate = e => { if (e.candidate) pushCandidate("calleeCandidates", e.candidate); };
    pc.onconnectionstatechange = () => onState && onState(pc.connectionState);

    await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);

    await callRef.update({
      answer: { type: answer.type, sdp: answer.sdp },
      status: "active", answeredAt: Date.now()
    });

    // Remove from incoming
    db.ref("incoming/" + myUid + "/" + callId).remove();

    listenCandidates("callerCandidates");

    const stRef = callRef.child("status");
    const stH = stRef.on("value", s => {
      if (s.val() === "ended") endCall(true);
    });
    unsubs.push(() => stRef.off("value", stH));
  }

  function endCall(silent) {
    try {
      if (localStream) localStream.getTracks().forEach(t => t.stop());
      if (pc) pc.close();
    } catch (e) {}
    if (callRef && !silent) callRef.update({ status: "ended", endedAt: Date.now() }).catch(()=>{});
    unsubs.forEach(u => { try { u(); } catch (e) {} });
    unsubs = []; pc = null; localStream = null; remoteStream = null; callRef = null;
  }

  function toggleMute() {
    if (!localStream) return false;
    const a = localStream.getAudioTracks()[0];
    if (!a) return false;
    a.enabled = !a.enabled;
    return !a.enabled; // true = muted
  }
  function toggleCam() {
    if (!localStream) return false;
    const v = localStream.getVideoTracks()[0];
    if (!v) return false;
    v.enabled = !v.enabled;
    return !v.enabled; // true = off
  }

  window.LTRTC = { startCall, acceptCall, endCall, toggleMute, toggleCam };
})();
