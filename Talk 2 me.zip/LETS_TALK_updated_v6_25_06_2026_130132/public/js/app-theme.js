// app-theme.js

auth.onAuthStateChanged(user => {
  if (!user) return;

  db.ref('users/' + user.uid + '/settings')
    .on('value', snapshot => {

      const settings = snapshot.val() || {};

      const color = settings.themeColor || '#25d366';

      applyTheme(color);

      const picker = document.getElementById('themePicker');
      if (picker) {
        picker.value = color;
      }

      const text = document.getElementById('selectedColor');
      if (text) {
        text.textContent = color;
      }
    });
});

function applyTheme(color){

  document.documentElement.style.setProperty(
    '--primary',
    color
  );

  const darkColor = shadeColor(color,-25);
  const lightColor = shadeColor(color,35);

  document.documentElement.style.setProperty(
    '--primary-dark',
    darkColor
  );

  document.documentElement.style.setProperty(
    '--primary-light',
    lightColor
  );

  document.documentElement.style.setProperty(
    '--green',
    color
  );

  document.documentElement.style.setProperty(
    '--green-dark',
    darkColor
  );

  document.documentElement.style.setProperty(
    '--sky',
    lightColor
  );
}

function saveCustomTheme(color) {

  const user = auth.currentUser;
  if (!user) return;

  applyTheme(color);

  db.ref('users/' + user.uid + '/settings')
    .update({
      themeColor: color
    });

  const text = document.getElementById('selectedColor');
  if (text) {
    text.textContent = color;
  }
}

window.saveCustomTheme = saveCustomTheme;

function shadeColor(color, percent) {

  let R = parseInt(color.substring(1,3),16);
  let G = parseInt(color.substring(3,5),16);
  let B = parseInt(color.substring(5,7),16);

  R = parseInt(R * (100 + percent) / 100);
  G = parseInt(G * (100 + percent) / 100);
  B = parseInt(B * (100 + percent) / 100);

  R = (R < 255) ? R : 255;
  G = (G < 255) ? G : 255;
  B = (B < 255) ? B : 255;

  R = (R > 0) ? R : 0;
  G = (G > 0) ? G : 0;
  B = (B > 0) ? B : 0;

  const RR = R.toString(16).padStart(2,'0');
  const GG = G.toString(16).padStart(2,'0');
  const BB = B.toString(16).padStart(2,'0');

  return "#" + RR + GG + BB;
}