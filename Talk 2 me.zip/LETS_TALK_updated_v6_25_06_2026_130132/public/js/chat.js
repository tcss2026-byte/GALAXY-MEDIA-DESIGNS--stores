// ==========================================================
// chat.js
// TALK 2 ME
// Part 1/?
// ==========================================================

const params = new URLSearchParams(location.search);
const peerUid = params.get("uid");
const groupId = params.get("gid");
const isGroup = !!groupId;

let me = null;
let peer = null;
let groupData = null;
let chatId = null;

let selectedMsgId = null;

let mediaRecorder = null;
let audioChunks = [];

const messagesEl = document.getElementById("messages");
const composer = document.getElementById("composer");

// ---- Reply state ----
let replyCtx = null;
const replyBar = document.getElementById("replyBar");
const rbName   = document.getElementById("rbName");
const rbText   = document.getElementById("rbText");
const rbClose  = document.getElementById("rbClose");
if (rbClose) rbClose.onclick = () => { replyCtx = null; replyBar.hidden = true; };
function setReply(msgId, msg){
  replyCtx = { id: msgId, from: msg.from, text: (msg.text || "["+(msg.type||"media")+"]").slice(0,120) };
  rbName.textContent = msg.from === (window.me && me.uid) ? "You" : "Reply";
  rbText.textContent = replyCtx.text;
  replyBar.hidden = false;
  msgInput.focus();
}

const msgInput = document.getElementById("msgInput");
const typingBar = document.getElementById("typingBar");
const sheet = document.getElementById("actionSheet");

function chatIdOf(a, b) {
    return [a, b].sort().join("_");
}

function escapeHtml(str) {
    return (str || "").replace(/[&<>"]/g, c => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        "\"": "&quot;"
    }[c]));
}

// ==========================================================
// AUTH
// ==========================================================

auth.onAuthStateChanged(async user => {

    if (!user) return;

    me = user;

    if (isGroup) {

        chatId = "group_" + groupId;

        db.ref("groups/" + groupId)
        .on("value", snap => {

            groupData = snap.val() || {};

            document.getElementById("peerName").textContent =
                groupData.name || "Group";

            if (groupData.photoURL) {

                document.getElementById("peerAvatar").innerHTML =
                    `<img src="${groupData.photoURL}">`;

            } else {

                document.getElementById("peerAvatar").textContent =
                    (groupData.name || "G")[0];

            }

            const members =
                Object.keys(groupData.members || {}).length;

            document.getElementById("peerStatus").textContent =
                members +
                " member" +
                (members === 1 ? "" : "s");

            applySendModeGate();

        });

    } else {

        chatId = chatIdOf(me.uid, peerUid);

        peer =
            (
                await db.ref("users/" + peerUid)
                .once("value")
            ).val() || {};

        document.getElementById("peerName").textContent =
            peer.name || "User";

        if (peer.photoURL) {

            document.getElementById("peerAvatar").innerHTML =
                `<img src="${peer.photoURL}">`;

        } else {

            document.getElementById("peerAvatar").textContent =
                (peer.name || "?")[0];

        }

        const peerInfo =
            document.getElementById("peerInfo");

        if (peerInfo) {

            peerInfo.onclick = () => {

                location.href =
                    "view-profile.html?uid=" + peerUid;

            };

        }

        // Presence

        db.ref("status/" + peerUid)
        .on("value", snap => {

            const value = snap.val();

            if (!value) return;

            document.getElementById("peerStatus").textContent =
                value.state === "online"
                    ? "online"
                    : "last seen " +
                      new Date(value.last_changed)
                      .toLocaleString();

        });

        // Typing

        if (!isGroup && peerUid) {

    db.ref("typing/" + chatId + "/" + peerUid)
        .on("value", snap => {

            if (!typingBar) return;

            const isTyping = snap.val();

            typingBar.style.display = isTyping ? "" : "none";
            typingBar.textContent = "typing...";
        });
}

if (isGroup && groupId) {

    db.ref("typingGroups/" + groupId)
        .on("value", snap => {

            if (!typingBar) return;

            const data = snap.val() || {};

            const typingUsers = Object.keys(data)
                .filter(uid => data[uid]);

            const others = typingUsers.filter(uid => uid !== me.uid);

            if (others.length === 0) {

                typingBar.style.display = "none";
                return;

            }

            typingBar.style.display = "";

            if (others.length === 1) {

                getUser(others[0]).then(user => {

                    typingBar.textContent =
                        (user.name || "Someone") + " is typing...";

                });

            } else {

                typingBar.textContent =
                    others.length + " people are typing...";

            }

        });

} // closes if (isGroup)

} // closes the else block

    // Start streaming messages for this chat
    listenMessages();

}); // closes auth.onAuthStateChanged()
// ==========================================================
// READ RECEIPTS
// ==========================================================

function markRead() {

    if (!me || !chatId) return;

    db.ref(
        "userChatState/" +
        me.uid +
        "/" +
        chatId +
        "/lastReadAt"
    ).set(Date.now());

}

// ==========================================================
// GROUP SEND MODE
// ==========================================================

function applySendModeGate() {

    if (!isGroup) return;

    if (!groupData) return;

    const mode =
        groupData.settings?.sendMode || "all";

    const isAdmin =
        !!(
            groupData.admins &&
            groupData.admins[me.uid]
        ) ||
        groupData.createdBy === me.uid;

    const blocked =
        mode === "admins" &&
        !isAdmin;

    msgInput.disabled = blocked;

    msgInput.placeholder =
        blocked
            ? "Only admins can send messages"
            : "Type a message";

    document
        .querySelectorAll(".composer button,.composer label")
        .forEach(el => {

            el.style.opacity =
                blocked ? ".4" : "1";

            el.style.pointerEvents =
                blocked ? "none" : "";

        });

}

// ==========================================================
// MESSAGES
// ==========================================================

function listenMessages() {

    db.ref("messages/" + chatId)
    .on("value", snap => {

        const data = snap.val() || {};

        messagesEl.innerHTML = "";

        Object.entries(data)

        .sort((a, b) => {

            return (a[1].time || a[1].at || 0) -

                   (b[1].time || b[1].at || 0);

        })

        .forEach(([id, m]) => {

            // Hidden only for me

            if (
                m.deletedFor &&
                m.deletedFor[me.uid]
            ) {
                return;
            }

            // --------------------------
            // System message
            // --------------------------

            if (
                m.type === "system" ||
                m.system
            ) {

                const sys =
                    document.createElement("div");

                sys.className = "system-msg";

                sys.style.cssText =
                    `
                    text-align:center;
                    color:var(--muted);
                    font-size:.8rem;
                    padding:6px;
                    margin:6px auto;
                    max-width:80%;
                    border-radius:8px;
                    background:rgba(255,255,255,.55);
                    `;

                sys.textContent =
                    m.text || "";

                messagesEl.appendChild(sys);

                return;

            }

            // --------------------------
            // Normal bubble
            // --------------------------

            const bubble =
                document.createElement("div");

            const outgoing =
                m.from === me.uid;

            bubble.className =
                "bubble " +
                (outgoing ? "out" : "in");

            bubble.dataset.id = id;

            // --------------------------
            // Deleted
            // --------------------------

            if (m.deletedForAll) {

                bubble.classList.add("deleted");

                bubble.innerHTML =
                    "🚫 This message was deleted";

            }

            else {

                // --------------------------
                // Reply To Status
                // --------------------------

                let replyBlock = "";

                if (m.replyTo) {
                    const r = m.replyTo;
                    const txt = (r.text||"").replace(/</g,"&lt;");
                    replyBlock = `<div class="reply-quote"><div class="rq-name">${r.from===me.uid?"You":"Reply"}</div><div class="rq-text">${txt}</div></div>`;
                }

                if (m.replyToStatus) {

                    const r =
                        m.replyToStatus;

                    const thumb =

                        r.thumbUrl

                        ?

                        `<img
                            src="${r.thumbUrl}"
                            style="
                                width:32px;
                                height:32px;
                                object-fit:cover;
                                border-radius:4px;
                            ">`

                        :

                        `<div
                            style="
                                width:32px;
                                height:32px;
                                border-radius:4px;
                                background:${r.bgColor || "#075e54"};
                            ">
                        </div>`;

                    replyBlock =

                        `
                        <div
                        style="
                            display:flex;
                            align-items:center;
                            gap:6px;
                            padding:6px;
                            margin-bottom:4px;
                            border-left:3px solid var(--green);
                            border-radius:4px;
                            background:rgba(0,0,0,.05);
                            font-size:.8rem;
                        ">

                            ${thumb}

                            <span>

                            Reply to status:

                            ${escapeHtml(
                                (r.text || "")
                                .slice(0, 40)
                            )}

                            </span>

                        </div>
                        `;

                }

                // --------------------------
                // Body
                // --------------------------

                let body = "";

                switch (m.type) {

                    case "image":

                        body =
                            `<img src="${m.url}">`;

                        break;

                    case "video":

                        body =
                            `<video
                                src="${m.url}"
                                controls>
                             </video>`;

                        break;

                    case "audio":

                        body =
                            `<audio
                                src="${m.url}"
                                controls>
                             </audio>`;

                        break;

                    case "file":

                        body =
                            `
                            <a
                                class="file"
                                href="${m.url}"
                                target="_blank">

                                📄
                                ${m.name || "File"}

                            </a>
                            `;

                        break;

                }

                const text =

                    m.text

                    ?

                    `<div>

                        ${escapeHtml(m.text)}

                     </div>`

                    :

                    "";

                bubble.innerHTML =

                    replyBlock +

                    body +

                    text +

                    `
                    <div class="time">

                    ${new Date(
                        m.time || m.at || 0
                    ).toLocaleTimeString(
                        [],
                        {
                            hour:"2-digit",
                            minute:"2-digit"
                        }
                    )}

                    ${outgoing ? "✓✓" : ""}

                    </div>
                    ` +

                    (

                        m.react

                        ?

                        `<span class="react">

                            ${m.react}

                        </span>`

                        :

                        ""

                    );

            }

            attachGestures(
                bubble,
                id,
                m
            );

            messagesEl.appendChild(
                bubble
            );

        });

        messagesEl.scrollTop =
            messagesEl.scrollHeight;

        markRead();

    });

}
// ==========================================================
// GESTURES & MESSAGE ACTIONS
// ==========================================================

// Double-tap to react
// Long-press to open action sheet

function attachGestures(el, id, m) {

    let lastTap = 0;
    let pressTimer = null;

    el.addEventListener("click", () => {

        const now = Date.now();

        if (now - lastTap < 300) {
            toggleReact(id, m);
        }

        lastTap = now;

    });

    el.addEventListener("touchstart", () => {

        pressTimer = setTimeout(() => {

            openSheet(id);

        }, 500);

    });

    el.addEventListener("touchend", () => {

        clearTimeout(pressTimer);

    });

    el.addEventListener("touchcancel", () => {

        clearTimeout(pressTimer);

    });

    el.addEventListener("mousedown", () => {

        pressTimer = setTimeout(() => {

            openSheet(id);

        }, 600);

    });

    el.addEventListener("mouseup", () => {

        clearTimeout(pressTimer);

    });

    el.addEventListener("mouseleave", () => {

        clearTimeout(pressTimer);

    });

}

// ==========================================================
// REACTION
// ==========================================================

function toggleReact(id, m) {

    db.ref(
        "messages/" +
        chatId +
        "/" +
        id +
        "/react"
    ).set(
        m.react ? null : "❤️"
    );

}

// ==========================================================
// ACTION SHEET
// ==========================================================

function openSheet(id) {

    selectedMsgId = id;

    sheet.classList.add("open");

}

sheet.addEventListener("click", e => {

    if (e.target.tagName !== "BUTTON") return;

    const action = e.target.dataset.act;

    const ref =
        db.ref(
            "messages/" +
            chatId +
            "/" +
            selectedMsgId
        );

    // --------------------------
    // React
    // --------------------------

    if (action === "reply") {
        ref.once("value").then(s => { const m = s.val(); if (m) setReply(selectedMsgId, m); });
    }

    if (action === "react") {

        ref.child("react").set("❤️");

    }

    // --------------------------
    // Forward
    // --------------------------

    if (action === "forward") {

        const uid =
            prompt("Forward to user UID:");

        if (uid) {

            ref.once("value").then(snap => {

                const msg = snap.val();

                if (!msg) return;

                const newChat =
                    chatIdOf(me.uid, uid);

                db.ref(
                    "messages/" +
                    newChat
                ).push({

                    ...msg,

                    from: me.uid,

                    time: Date.now(),

                    forwarded: true,

                    react: null

                });

                updateUserChats(
                    uid,
                    msg.text || "[media]"
                );

            });

        }

    }

    // --------------------------
    // Delete for me
    // --------------------------

    if (action === "deleteMe") {

        ref.child(
            "deletedFor/" + me.uid
        ).set(true);

    }

    // --------------------------
    // Delete for everyone
    // --------------------------

    if (action === "deleteAll") {

        ref.update({

            deletedForAll: true,

            text: "",

            url: ""

        });

    }

    sheet.classList.remove("open");

});

// ==========================================================
// TYPING INDICATOR
// ==========================================================

msgInput.addEventListener("input", () => {

    if (isGroup) return;

    db.ref(
        "typing/" +
        chatId +
        "/" +
        me.uid
    ).set(true);

    clearTimeout(window.__typingTimeout);

    window.__typingTimeout =
        setTimeout(() => {

            db.ref(
                "typing/" +
                chatId +
                "/" +
                me.uid
            ).set(false);

        }, 1500);

});

// ==========================================================
// SEND TEXT
// ==========================================================

composer.addEventListener("submit", e => {

    e.preventDefault();

    const text =
        msgInput.value.trim();

    if (!text) return;

    sendMessage({

        type: "text",

        text,

        replyTo: replyCtx ? { id: replyCtx.id, from: replyCtx.from, text: replyCtx.text } : null

    });

    replyCtx = null; replyBar.hidden = true;

    msgInput.value = "";

});

// ==========================================================
// SEND MESSAGE
// ==========================================================

function sendMessage(payload) {

    const msg = {

        from: me.uid,

        time: Date.now(),

        ...payload

    };

    db.ref(
        "messages/" +
        chatId
    ).push(msg);

    const snippet =
        payload.text ||
        "[" + payload.type + "]";

    if (isGroup) {

        db.ref(
            "groups/" +
            groupId
        ).update({

            lastMessage: snippet,

            lastMessageAt: Date.now()

        });

    }

    else {

        updateUserChats(
            peerUid,
            snippet
        );

        updateUserChats(
            me.uid,
            snippet,
            peerUid
        );

    }

    markRead();

}

// ==========================================================
// USER CHATS
// ==========================================================

function updateUserChats(
    forUid,
    snippet,
    otherUid
) {

    const other =

        otherUid ||

        (

            forUid === me.uid

                ? peerUid

                : me.uid

        );

    db.ref(

        "userChats/" +

        forUid +

        "/" +

        other

    ).set({

        lastMessage: snippet,

        time: Date.now()

    });

}
// ==========================================================
// FILES / MEDIA
// ==========================================================

const fileInput = document.getElementById("fileInput");
const mediaInput = document.getElementById("mediaInput");

if (fileInput) {

    fileInput.addEventListener("change", e => {

        const file = e.target.files[0];

        if (!file) return;

        uploadAndSend(file, "file");

    });

}

if (mediaInput) {

    mediaInput.addEventListener("change", e => {

        const file = e.target.files[0];

        if (!file) return;

        const type =
            file.type.startsWith("video")
                ? "video"
                : "image";

        uploadAndSend(file, type);

    });

}

// ==========================================================
// UPLOAD
// ==========================================================

async function uploadAndSend(file, type) {

    if (!file) return;

    try {

        const storageRef =
            storage.ref(
                "chats/" +
                chatId +
                "/" +
                Date.now() +
                "_" +
                file.name
            );

        await storageRef.put(file);

        const url = await storageRef.getDownloadURL();

        sendMessage({
            type,
            url,
            name: file.name
        });

    } catch (err) {

        console.error(err);
        alert("Upload failed");

    }
}
// ==========================================================
// AUDIO RECORDING
// ==========================================================

const micBtn =
    document.getElementById("micBtn");

if (micBtn) {

    micBtn.addEventListener(
        "mousedown",
        startRecording
    );

    micBtn.addEventListener(
        "touchstart",
        startRecording
    );

    micBtn.addEventListener(
        "mouseup",
        stopRecording
    );

    micBtn.addEventListener(
        "mouseleave",
        stopRecording
    );

    micBtn.addEventListener(
        "touchend",
        stopRecording
    );

}

async function startRecording(e) {

    e.preventDefault();

    if (
        mediaRecorder &&
        mediaRecorder.state === "recording"
    ) {
        return;
    }

    try {

        const stream =
            await navigator.mediaDevices
                .getUserMedia({

                    audio: true

                });

        mediaRecorder =
            new MediaRecorder(stream);

        audioChunks = [];

        mediaRecorder.ondataavailable = ev => {

            audioChunks.push(ev.data);

        };

        mediaRecorder.onstop = async () => {

            const blob =
                new Blob(audioChunks, {

                    type: "audio/webm"

                });

            const ref =
                storage.ref(

                    "chats/" +

                    chatId +

                    "/" +

                    Date.now() +

                    ".webm"

                );

            await ref.put(blob);

            const url =
                await ref.getDownloadURL();

            sendMessage({

                type: "audio",

                url

            });

            stream
                .getTracks()
                .forEach(track => {

                    track.stop();

                });

        };

        mediaRecorder.start();

        micBtn.classList.add(
            "recording"
        );

    }

    catch (err) {

        alert(
            "Microphone permission denied."
        );

    }

}

function stopRecording() {

    if (
        mediaRecorder &&
        mediaRecorder.state === "recording"
    ) {

        mediaRecorder.stop();

        micBtn.classList.remove(
            "recording"
        );

    }

}

// ==========================================================
// CLEAR CHAT (FOR ME)
// ==========================================================

function clearChat() {

    if (

        !confirm(

            "Clear all messages in this chat (only for you)?"

        )

    ) {
        return;
    }

    db.ref(
        "messages/" + chatId
    )

    .once("value")

    .then(snapshot => {

        const data =
            snapshot.val() || {};

        const updates = {};

        Object.keys(data).forEach(id => {

            updates[
                id +
                "/deletedFor/" +
                me.uid
            ] = true;

        });

        db.ref(
            "messages/" + chatId
        ).update(updates);

    });

}

window.clearChat = clearChat;

// ==========================================================
// END OF chat.js
// ==========================================================
