// Shared AI helper used by ai-chat.js
// Reads window.AI_API_BASE (set on the page, in app-theme, or in localStorage)
// and falls back to localhost for local dev.

const AI = (() => {

  function base() {
    return (
      window.AI_API_BASE ||
      localStorage.getItem("ai_api_base") ||
      "http://localhost:3000"
    ).replace(/\/+$/, "");
  }

  async function reply(question) {
    try {
      const res = await fetch(base() + "/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: question })
      });
      const data = await res.json();
      return data.reply || "⚠️ Empty response from AI.";
    } catch (err) {
      console.error("[AI.reply]", err);
      return "⚠️ I'm unable to reach the AI server.";
    }
  }

  async function chat(history) {
    try {
      const res = await fetch(base() + "/api/chat/history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ history })
      });
      const data = await res.json();
      return data.reply || "⚠️ Empty response from AI.";
    } catch (err) {
      console.error("[AI.chat]", err);
      return "⚠️ I'm unable to reach the AI server.";
    }
  }

  return { reply, chat, base };
})();

window.AI = AI;
