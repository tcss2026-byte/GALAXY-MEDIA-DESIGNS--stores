// ================================
// GROUP-INFO.JS
// ================================

const params = new URLSearchParams(location.search);
const gid = params.get("gid");
if (!gid) location.href = "groups.html";

const giAvatar = document.getElementById("giAvatar");
const giName   = document.getElementById("giName");
const giSub    = document.getElementById("giSub");
const giDesc   = document.getElementById("giDesc");
const giCreated= document.getElementById("giCreated");
const editBtn  = document.getElementById("editBtn");
const memberCount = document.getElementById("memberCount");
const memberList  = document.getElementById("memberList");
const addMembersBtn = document.getElementById("addMembersBtn");
const inviteLinkBtn = document.getElementById("inviteLinkBtn");
const muteBtn   = document.getElementById("muteBtn");
const reportBtn = document.getElementById("reportBtn");
const exitBtn   = document.getElementById("exitBtn");
const deleteBtn = document.getElementById("deleteBtn");

const addOverlay = document.getElementById("addOverlay");
const addCancel  = document.getElementById("addCancel");
const addDone    = document.getElementById("addDone");
const addPicker  = document.getElementById("addPicker");
const addChips   = document.getElementById("addChips");

const sheet     = document.getElementById("memberSheet");
const msBack    = document.getElementById("msBack");
const msName    = document.getElementById("msName");
const msMessage = document.getElementById("msMessage");
const msMakeAdmin   = document.getElementById("msMakeAdmin");
const msRemoveAdmin = document.getElementById("msRemoveAdmin");
const msRemove  = document.getElementById("msRemove");
const msCancel  = document.getElementById("msCancel");

let myUid = null;
let group = null;
let amAdmin = false;

const userCache = {};
function getUser(uid){
  if (userCache[uid]) return Promise.resolve(userCache[uid]);
  return db.ref("users/"+uid).once("value").then(s=>{userCache[uid]=s.val()||{};return userCache[uid];});
}
function avatarHTML(u){
  if (u && u.photoURL) return `<img src="${u.photoURL}" alt="">`;
  return ((u&&u.name)||"?")[0].toUpperCase();
}

auth.onAuthStateChanged(user => {
  if (!user) return;
  myUid = user.uid;
  db.ref("groups/"+gid).on("value", snap => {
    group = snap.val();
    if (!group){ alert("Group not found"); location.href="groups.html"; return; }
    render();
  });
});

async function render(){
  amAdmin = !!(group.admins && group.admins[myUid]);
  giName.textContent = group.name || "Group";
  giDesc.textContent = group.description || "Tap to add description.";
  giAvatar.innerHTML = group.photoURL ? `<img src="${group.photoURL}">` : "👥";
  const cnt = Object.keys(group.members||{}).length;
  giSub.textContent = `Group · ${cnt} member${cnt!==1?'s':''}`;
  memberCount.textContent = `${cnt} members`;

  const creator = group.createdBy ? (await getUser(group.createdBy)).name || "Someone" : "Someone";
  const ts = group.createdAt ? new Date(group.createdAt).toLocaleDateString() : "";
  giCreated.textContent = `Created by ${creator}${ts?(" on "+ts):""}`;

  editBtn.hidden = !amAdmin;
  addMembersBtn.hidden = !amAdmin;
  deleteBtn.hidden = !(amAdmin && group.createdBy === myUid);

  // members
  memberList.innerHTML = "";
  const memberUids = Object.keys(group.members||{});
  // put me first, then admins, then others by name
  memberUids.sort((a,b)=>{
    if (a===myUid) return -1;
    if (b===myUid) return 1;
    const aa = group.admins&&group.admins[a]?0:1;
    const bb = group.admins&&group.admins[b]?0:1;
    return aa-bb;
  });
  for (const uid of memberUids){
    const u = await getUser(uid);
    const row = document.createElement("div");
    row.className = "member-row";
    const isAdmin = group.admins && group.admins[uid];
    row.innerHTML = `
      <div class="avatar">${avatarHTML(u)}</div>
      <div class="meta">
        <div class="nm">${uid===myUid?"You":(u.name||"User")} ${isAdmin?'<span class="tag">Group admin</span>':''}</div>
        <div class="sb">${u.status||u.email||""}</div>
      </div>`;
    row.onclick = () => uid===myUid ? null : openSheet(uid, u, isAdmin);
    memberList.appendChild(row);
  }
}

editBtn.onclick = async () => {
  const n = prompt("Group name", group.name||"");
  if (n===null) return;
  const d = prompt("Group description", group.description||"");
  if (d===null) return;
  await db.ref("groups/"+gid).update({name:n.trim()||group.name, description:d.trim()});
};

inviteLinkBtn.onclick = () => {
  const link = location.origin + "/pages/join-group.html?gid=" + gid;
  if (navigator.share){
    navigator.share({title: group.name||"Group", text: "Join my group on LET'S TALK", url: link}).catch(()=>{});
  } else if (navigator.clipboard){
    navigator.clipboard.writeText(link).then(()=>alert("Invite link copied:\n"+link));
  } else alert(link);
};

muteBtn.onclick = async () => {
  const mutes = group.mutes || {};
  if (mutes[myUid]){
    await db.ref(`groups/${gid}/mutes/${myUid}`).remove();
    alert("Notifications unmuted");
  } else {
    await db.ref(`groups/${gid}/mutes/${myUid}`).set(true);
    alert("Notifications muted");
  }
};
reportBtn.onclick = async () => {
  const reason = prompt("Why are you reporting this group?");
  if (!reason) return;
  await db.ref("reports").push({type:"group", gid, by:myUid, reason, time:Date.now()});
  alert("Report submitted. Thank you.");
};
exitBtn.onclick = async () => {
  if (!confirm("Exit group? You'll stop receiving messages.")) return;
  const updates = {};
  updates[`groups/${gid}/members/${myUid}`] = null;
  updates[`groups/${gid}/admins/${myUid}`]  = null;
  updates[`userGroups/${myUid}/${gid}`]     = null;
  await db.ref().update(updates);
  const me = await getUser(myUid);
  await db.ref("groupMessages/"+gid).push({type:"system", text:`${me.name||"User"} left`, time:Date.now()});
  location.href = "home.html";
};
deleteBtn.onclick = async () => {
  if (!confirm("Delete group for everyone? This cannot be undone.")) return;
  const updates = {};
  Object.keys(group.members||{}).forEach(uid=>{
    updates[`userGroups/${uid}/${gid}`] = null;
  });
  updates[`groups/${gid}`]        = null;
  updates[`groupMessages/${gid}`] = null;
  await db.ref().update(updates);
  location.href = "groups.html";
};

// ---------- Add members ----------
const addPicked = new Set();
let addContacts = [];

addMembersBtn.onclick = async () => {
  addOverlay.hidden = false;
  addPicked.clear(); addChips.innerHTML = "";
  addPicker.innerHTML = `<div class="empty">Loading…</div>`;
  const chats = (await db.ref("userChats/"+myUid).once("value")).val() || {};
  addContacts = [];
  for (const uid of Object.keys(chats)){
    if (group.members && group.members[uid]) continue;
    addContacts.push({uid, ...(await getUser(uid))});
  }
  renderAddPicker();
};
addCancel.onclick = () => addOverlay.hidden = true;
addDone.onclick = async () => {
  if (!addPicked.size){ addOverlay.hidden=true; return; }
  const updates = {};
  const me = await getUser(myUid);
  for (const uid of addPicked){
    updates[`groups/${gid}/members/${uid}`] = true;
    updates[`userGroups/${uid}/${gid}`]     = true;
    const u = await getUser(uid);
    await db.ref("groupMessages/"+gid).push({type:"system", text:`${me.name||"Admin"} added ${u.name||"user"}`, time:Date.now()});
  }
  await db.ref().update(updates);
  addOverlay.hidden = true;
};

function renderAddPicker(){
  addPicker.innerHTML = "";
  if (!addContacts.length){
    addPicker.innerHTML = `<div class="empty">No contacts to add.</div>`;
    return;
  }
  addContacts.forEach(u=>{
    const r = document.createElement("div");
    r.className = "list-item contact-row" + (addPicked.has(u.uid)?" selected":"");
    r.innerHTML = `
      <div class="avatar">${avatarHTML(u)}</div>
      <div class="meta">
        <div class="name"><span>${u.name||"User"}</span></div>
        <div class="snippet">${u.email||""}</div>
      </div>
      <div class="check">✓</div>`;
    r.onclick = () => {
      if (addPicked.has(u.uid)) addPicked.delete(u.uid); else addPicked.add(u.uid);
      r.classList.toggle("selected");
      renderAddChips();
    };
    addPicker.appendChild(r);
  });
}
function renderAddChips(){
  addChips.innerHTML = "";
  addPicked.forEach(uid=>{
    const u = addContacts.find(c=>c.uid===uid)||{};
    const c = document.createElement("div");
    c.className = "chip";
    c.innerHTML = `<div class="avatar">${avatarHTML(u)}</div>${u.name||"User"}<span class="x">✕</span>`;
    c.querySelector(".x").onclick = ev => { ev.stopPropagation(); addPicked.delete(uid); renderAddChips(); renderAddPicker(); };
    addChips.appendChild(c);
  });
}

// ---------- Member sheet ----------
let sheetUid = null;
function openSheet(uid, u, isAdmin){
  sheetUid = uid;
  msName.textContent = u.name || "User";
  msMakeAdmin.hidden   = !amAdmin || isAdmin;
  msRemoveAdmin.hidden = !amAdmin || !isAdmin;
  msRemove.hidden      = !amAdmin;
  sheet.hidden = false;
}
msBack.onclick = msCancel.onclick = () => sheet.hidden = true;
msMessage.onclick = () => { sheet.hidden=true; location.href = "chat.html?uid="+sheetUid; };
msMakeAdmin.onclick = async () => {
  await db.ref(`groups/${gid}/admins/${sheetUid}`).set(true);
  const me = await getUser(myUid), tg = await getUser(sheetUid);
  await db.ref("groupMessages/"+gid).push({type:"system",text:`${me.name||"Admin"} made ${tg.name||"user"} an admin`,time:Date.now()});
  sheet.hidden = true;
};
msRemoveAdmin.onclick = async () => {
  await db.ref(`groups/${gid}/admins/${sheetUid}`).remove();
  sheet.hidden = true;
};
msRemove.onclick = async () => {
  if (!confirm("Remove this member from the group?")) return;
  const updates = {};
  updates[`groups/${gid}/members/${sheetUid}`] = null;
  updates[`groups/${gid}/admins/${sheetUid}`]  = null;
  updates[`userGroups/${sheetUid}/${gid}`]     = null;
  await db.ref().update(updates);
  const me = await getUser(myUid), tg = await getUser(sheetUid);
  await db.ref("groupMessages/"+gid).push({type:"system",text:`${me.name||"Admin"} removed ${tg.name||"user"}`,time:Date.now()});
  sheet.hidden = true;
};
