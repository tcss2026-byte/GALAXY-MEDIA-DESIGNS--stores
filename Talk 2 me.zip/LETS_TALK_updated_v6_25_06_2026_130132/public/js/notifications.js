auth.onAuthStateChanged(user => {
  if (!user) return;

  db.ref('users/' + user.uid + '/settings')
    .once('value')
    .then(snapshot => {

      const settings = snapshot.val() || {};

      const msg = document.getElementById('msg');
      const vibration = document.getElementById('vibration');

      if (msg) {
        msg.checked = settings.notifications !== false;
      }

      if (vibration) {
        vibration.checked = settings.vibration !== false;
      }
    });
});

function saveNotifications() {

  const user = auth.currentUser;
  if (!user) return;

  const msg = document.getElementById('msg');
  const vibration = document.getElementById('vibration');

  db.ref('users/' + user.uid + '/settings').update({
    notifications: msg.checked,
    vibration: vibration.checked
  });
}

window.saveNotifications = saveNotifications;