// ================================
// HOME.JS - PART 1
// Chats Page Only
// ================================

// ---------- Chat List ----------
const chatList = document.getElementById("chatList");

// ---------- Floating Action Button ----------
const fab = document.getElementById("fab");

if (fab) {
    fab.onclick = () => {
        location.href = "contacts.html";
    };
}

// ---------- AI Button ----------
const fabAI = document.getElementById("fabAI");

if (fabAI) {
    fabAI.onclick = () => {
        location.href = "ai-chat.html";
    };
}

// ---------- Helpers ----------

function chatIdOf(a, b) {
    return [a, b].sort().join("_");
}

function formatTime(time) {

    if (!time) return "";

    const date = new Date(time);
    const today = new Date();

    if (
        date.getDate() === today.getDate() &&
        date.getMonth() === today.getMonth() &&
        date.getFullYear() === today.getFullYear()
    ) {
        return date.toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
        });
    }

    return date.toLocaleDateString([], {
        day: "numeric",
        month: "short"
    });
}

const userCache = {};

function getUser(uid) {

    if (userCache[uid]) {
        return Promise.resolve(userCache[uid]);
    }

    return db.ref("users/" + uid)
        .once("value")
        .then(snap => {

            userCache[uid] = snap.val() || {};

            return userCache[uid];
        });
}

function avatarHTML(user) {

    if (user.photoURL) {
        return `<img src="${user.photoURL}" alt="">`;
    }

    return (user.name || "?")[0].toUpperCase();
}

// ---------- Search ----------
const chatSearch =
    document.getElementById("searchInput") ||
    document.getElementById("chatSearch") ||
    document.getElementById("search");

function filterChats(query) {

    const q = query.toLowerCase();

    if (!chatList) return;

    chatList.querySelectorAll(".list-item").forEach(item => {

        const text = (item.dataset.search || "").toLowerCase();

        item.style.display = text.includes(q) ? "" : "none";

    });

}

if (chatSearch) {

    chatSearch.addEventListener("input", e => {
        filterChats(e.target.value.trim());
    });

}

// ---------- Authentication ----------
auth.onAuthStateChanged(user => {

    if (!user) return;

    db.ref("users/" + user.uid).update({
        online: true,
        lastSeen: Date.now()
    });

    window.addEventListener("beforeunload", () => {

        db.ref("users/" + user.uid).update({
            online: false,
            lastSeen: Date.now()
        });

    });

    loadChats(user);

});

// ================================
// HOME.JS - PART 2
// Chats Loader
// ================================

function loadChats(user) {

    db.ref("userChats/" + user.uid).on("value", async snap => {

        const chats = snap.val() || {};

        const entries = Object.entries(chats)
            .sort((a, b) => (b[1].time || 0) - (a[1].time || 0));

        chatList.innerHTML = "";

        if (!entries.length) {

            chatList.innerHTML = `
                <div class="empty">
                    No chats yet.<br>
                    Tap + to start chatting.
                </div>
            `;

            return;

        }

        for (const [otherUid, meta] of entries) {

            const u = await getUser(otherUid);

            const item = document.createElement("div");
            item.className = "list-item";

            item.dataset.search = (
                (u.name || "") +
                " " +
                (u.email || "") +
                " " +
                (meta.lastMessage || "")
            ).toLowerCase();

            const online = u.online
                ? `<span style="color:#25D366;font-size:12px;">● Online</span>`
                : "";

            const unread = meta.unread
                ? `<span class="badge">${meta.unread}</span>`
                : "";

            item.innerHTML = `

                <div class="avatar">
                    ${avatarHTML(u)}
                </div>

                <div class="meta">

                    <div class="name">

                        <span>
                            ${u.name || "User"}
                            ${u.isBusiness ? " 🏢" : ""}
                        </span>

                        <span class="time">
                            ${formatTime(meta.time)}
                        </span>

                    </div>

                    <div class="snippet">

                        ${meta.lastMessage || ""}

                        <br>

                        <small>${online}</small>

                    </div>

                </div>

                ${unread}

            `;

            item.onclick = () => {
                location.href = `chat.html?uid=${otherUid}`;
            };

            chatList.appendChild(item);

        }

    });

}
// ================================
// HOME.JS - PART 3
// Presence & Utilities
// ================================

// Refresh online status every minute
setInterval(() => {

    const user = auth.currentUser;

    if (!user) return;

    db.ref("users/" + user.uid).update({

        online: true,

        lastSeen: Date.now()

    });

}, 60000);

// Mark user offline when leaving
window.addEventListener("beforeunload", () => {

    const user = auth.currentUser;

    if (!user) return;

    db.ref("users/" + user.uid).update({

        online: false,

        lastSeen: Date.now()

    });

});

// ================================
// END OF HOME.JS
// ================================