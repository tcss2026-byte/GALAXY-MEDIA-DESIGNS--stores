auth.onAuthStateChanged(user => {
  if (!user) return;
  db.ref('users/' + user.uid).on('value', s => {
    const u = s.val() || {};
    document.getElementById('meName').textContent = u.name || user.email;
    document.getElementById('meBio').textContent = u.bio || '';
    document.getElementById('meAvatar').innerHTML = u.photoURL?`<img src="${u.photoURL}"/>`:(u.name||'?')[0];
  });
});
function logout(){ auth.signOut().then(()=>location.href='login.html'); }
window.logout = logout;
