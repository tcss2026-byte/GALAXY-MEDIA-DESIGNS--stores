// AI chat routes
// POST /api/chat          - single message  { message } -> { reply }
// POST /api/chat/history  - multi-turn      { history:[{role,text}] } -> { reply }
// GET  /api/chat/health   - quick liveness check

import { Router } from "express";
import { ask, chat } from "../services/gemini.js";

const router = Router();

router.get("/health", (_req, res) => {
  res.json({ ok: true, hasKey: Boolean(process.env.GEMINI_API_KEY) });
});

router.post("/", async (req, res) => {
  try {
    const { message } = req.body || {};
    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "message (string) is required" });
    }
    const reply = await ask(message);
    res.json({ reply });
  } catch (err) {
    console.error("[ai] /api/chat failed:", err);
    res.status(500).json({ error: "Failed to generate response." });
  }
});

router.post("/history", async (req, res) => {
  try {
    const { history } = req.body || {};
    if (!Array.isArray(history) || history.length === 0) {
      return res.status(400).json({ error: "history (non-empty array) is required" });
    }
    // Hard cap to keep prompts cheap.
    const trimmed = history.slice(-20).map((t) => ({
      role: t.role === "assistant" || t.role === "model" ? "model" : "user",
      text: String(t.text ?? "").slice(0, 4000),
    }));
    const reply = await chat(trimmed);
    res.json({ reply });
  } catch (err) {
    console.error("[ai] /api/chat/history failed:", err);
    res.status(500).json({ error: "Failed to generate response." });
  }
});

export default router;
